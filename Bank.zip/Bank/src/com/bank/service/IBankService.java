package com.bank.service;

import java.util.List;



import com.bank.entities.User;

public interface IBankService {

	List<User> getaccountId(int uId, String uPwd);

}
