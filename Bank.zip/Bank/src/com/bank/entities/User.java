package com.bank.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

@Entity
@Table(name="customer_table")
public class User {

	@Id
	@Column(name="ACCOUNT_ID")
	@NotNull
	private int accountId ;
	
	@Column(name="USER_ID")
	@NotNull
	 private int userId  ; 
	
	@Column(name="LOGIN_PASSWORD")
	@NotNull(message="MANDATORY")
	@Pattern(regexp="^(?=.*\\d)(?=.*[a-z])(?=.*[A-Z]).{8,}$",message="must contains at least one digit, one uppercase, one lowercase, no whitespace with minimum 8 characters.")
	 private String loginPassword  ;
	
	@Column(name="SECRET_QUESTION")
	@NotNull(message="MANDATORY")
	private String secretQuestion   ; 
	@Column(name="TRANSACTION_PASSWORD")
	@NotNull(message="MANDATORY")
	 private String transactionPassword  ;
	@Column(name="LOCK_STATUS")
	@NotNull(message="MANDATORY")
	 private String lockStatus;
	 
	 
	public User() {
		super();
		
	}


	public int getAccountId() {
		return accountId;
	}


	public void setAccountId(int accountId) {
		this.accountId = accountId;
	}


	

	public int getUserId() {
		return userId;
	}
 

	public void setUserId(int userId) {
		this.userId = userId;
	}


	public String getLoginPassword() {
		return loginPassword;
	}


	public void setLoginPassword(String loginPassword) {
		this.loginPassword = loginPassword;
	}


	public String getSecretQuestion() {
		return secretQuestion;
	}


	public void setSecretQuestion(String secretQuestion) {
		this.secretQuestion = secretQuestion;
	}


	public String getTransactionPassword() {
		return transactionPassword;
	}


	public void setTransactionPassword(String transactionPassword) {
		this.transactionPassword = transactionPassword;
	}


	public String getLockStatus() {
		return lockStatus;
	}


	public void setLockStatus(String lockStatus) {
		this.lockStatus = lockStatus;
	}


	

}
