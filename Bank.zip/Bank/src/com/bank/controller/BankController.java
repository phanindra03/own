package com.bank.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.bank.entities.User;
import com.bank.service.IBankService;

@Controller
public class BankController {
	@Autowired
	IBankService service;
	List<User> accId;
	
	@RequestMapping(value="/index")
	public String load(){
		return "homepage";
	}
	
	/*@RequestMapping(value="/CustomerLogin")
	public String customerLogin(Model model){
		User user=new User();
		model.addAttribute("userdetails",user);
		return "customerLogin";
	}*/
	
	@RequestMapping(value="/BCustomerLogin")
	public String customerLogin(Model model){
		model.addAttribute("userdetails",new User());
		
		
		return "customerLogin";
	}
	
	
	@RequestMapping(value="/customer")
	public String login(@ModelAttribute("userdetails") User user,Model model){
		int uId=user.getUserId();
		String uPwd=user.getLoginPassword();
		accId=service.getaccountId(uId,uPwd);
		if(!accId.isEmpty()){
		/*	model.addAttribute("customer_account",accId);*/
			return "customer";
		}
		return "customerLogin";
	}

}
