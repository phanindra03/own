package com.bank.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.bank.entities.User;
@Repository
public class BankDao implements IBankDao{
	@PersistenceContext
	EntityManager em;

	@Override
	public List<User> getaccountId(int uId, String uPwd) {
	TypedQuery<User> qry=em.createQuery("SELECT h FROM User h WHERE h.userId=:paccountId",User.class);
	qry.setParameter("paccountId",uId);
	List<User> list = qry.getResultList();
	if(!list.isEmpty()){
		return list;
	}
		return null;
	}

}
