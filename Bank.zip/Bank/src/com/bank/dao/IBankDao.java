package com.bank.dao;

import java.util.List;

import com.bank.entities.User;

public interface IBankDao {

	List<User> getaccountId(int uId, String uPwd);

}
